﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BOL;
using BLL;


namespace BugTrackingREST.Controllers
{
    public class PeopleController : ApiController
    {
        // GET: api/People
        public IEnumerable<People> Get()
        {
            return BusinessManager.GetAllPeople();
        }

         //GET: api/People/5
        public People Get(int id)
        {
            return BusinessManager.GetPeople(id);
        }

        // POST: api/People
        public void Post([FromBody] People newPerson )
        {
            BusinessManager.Insert(newPerson);
        }

        // PUT: api/People/5
        public HttpResponseMessage Put(int id, [FromBody] People existingPerson)
        {
            People obj = new People();
            obj = BusinessManager.Update(id,existingPerson);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, obj);
            return response;
        }

        // DELETE: api/People/5
        [HttpDelete]
        public void Delete(int id)
        {
            BusinessManager.Delete(id);
        }
    }
}
